// Hokm Online v27 — profile, progression and leaderboard
const {Pool} = require("pg");
const {applyResult} = require("./v27_progression");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.DB_POOL_SIZE || 10),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000
});

async function getProfile(userId) {
  const r = await pool.query(`
    SELECT u.id,u.username,u.display_name,u.created_at,
           s.games_played,s.games_won,s.total_score,
           s.xp,s.level,s.rating,s.streak,s.best_streak,
           CASE WHEN s.games_played=0 THEN 0
                ELSE ROUND((s.games_won::numeric/s.games_played)*100,2)
           END AS win_rate
    FROM users u
    JOIN player_stats s ON s.user_id=u.id
    WHERE u.id=$1`, [userId]);
  return r.rows[0] || null;
}

async function getAchievements(userId) {
  const r = await pool.query(`
    SELECT achievement_code, unlocked_at
    FROM player_achievements
    WHERE user_id=$1
    ORDER BY unlocked_at DESC`, [userId]);
  return r.rows;
}

async function unlockAchievement(client, userId, code) {
  await client.query(`
    INSERT INTO player_achievements(user_id,achievement_code)
    VALUES($1,$2) ON CONFLICT DO NOTHING`, [userId, code]);
}

async function applyGameResult(game) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const exists = await client.query(
      `SELECT 1 FROM game_history WHERE id=$1 FOR UPDATE`, [game.id]
    );
    if (exists.rowCount) {
      await client.query("COMMIT");
      return {recorded:false, duplicate:true};
    }

    await client.query(`
      INSERT INTO game_history
      (id,room_code,started_at,finished_at,winner_team,result_json,mode)
      VALUES($1,$2,$3,$4,$5,$6,$7)`,
      [game.id,game.roomCode,game.startedAt,game.finishedAt,
       game.winnerTeam,JSON.stringify(game.result||{}),game.mode||"classic"]
    );

    const progression = [];

    for (const p of game.players) {
      const old = await client.query(`
        SELECT xp,level,rating,streak,best_streak
        FROM player_stats WHERE user_id=$1 FOR UPDATE`, [p.userId]);

      if (!old.rowCount) throw new Error("PLAYER_STATS_NOT_FOUND");

      const s = old.rows[0];
      const next = applyResult(s, Boolean(p.won));

      await client.query(`
        INSERT INTO game_players(game_id,user_id,team,seat,score,won)
        VALUES($1,$2,$3,$4,$5,$6)`,
        [game.id,p.userId,p.team,p.seat,p.score||0,Boolean(p.won)]
      );

      await client.query(`
        UPDATE player_stats SET
          games_played=games_played+1,
          games_won=games_won+$2,
          total_score=total_score+$3,
          xp=$4,level=$5,rating=$6,streak=$7,best_streak=$8,
          updated_at=NOW()
        WHERE user_id=$1`,
        [p.userId,p.won?1:0,p.score||0,
         next.xp,next.level,next.rating,next.streak,next.bestStreak]
      );

      // Achievements
      if (p.won) await unlockAchievement(client,p.userId,"FIRST_WIN");
      if (next.streak >= 3) await unlockAchievement(client,p.userId,"WIN_STREAK_3");
      if (next.streak >= 5) await unlockAchievement(client,p.userId,"WIN_STREAK_5");
      if (next.level >= 5) await unlockAchievement(client,p.userId,"LEVEL_5");

      progression.push({
        userId:p.userId,won:Boolean(p.won),
        xpGained:next.gained,level:next.level,
        rating:next.rating,streak:next.streak
      });
    }

    await client.query("COMMIT");
    return {recorded:true,duplicate:false,progression};
  } catch(e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}

async function leaderboard(limit=20) {
  const n=Math.max(1,Math.min(100,Number(limit)||20));
  const r=await pool.query(`
    SELECT u.id,u.display_name,s.level,s.xp,s.rating,
           s.games_played,s.games_won,s.streak,s.best_streak,
           CASE WHEN s.games_played=0 THEN 0
                ELSE ROUND((s.games_won::numeric/s.games_played)*100,2)
           END AS win_rate
    FROM player_stats s
    JOIN users u ON u.id=s.user_id
    ORDER BY s.rating DESC,s.games_won DESC,s.xp DESC
    LIMIT $1`,[n]);
  return r.rows;
}

async function recentGames(userId, limit=20) {
  const n=Math.max(1,Math.min(50,Number(limit)||20));
  const r=await pool.query(`
    SELECT g.id,g.room_code,g.started_at,g.finished_at,
           g.winner_team,g.mode,g.result_json,gp.team,gp.score,gp.won
    FROM game_history g
    JOIN game_players gp ON gp.game_id=g.id
    WHERE gp.user_id=$1
    ORDER BY g.finished_at DESC NULLS LAST
    LIMIT $2`,[userId,n]);
  return r.rows;
}

module.exports={pool,getProfile,getAchievements,applyGameResult,leaderboard,recentGames};
