// Hokm Online v16
// پروفایل، دوستان، تاریخچه بازی و رتبه‌بندی

function createProfile(data = {}) {
  return {
    id: String(data.id || ""),
    name: data.name || "بازیکن",
    avatar: data.avatar || null,
    wins: Number(data.wins || 0),
    losses: Number(data.losses || 0),
    coins: Number(data.coins || 0),
    rating: Number(data.rating || 1000),
    friends: [...new Set((data.friends || []).map(String))],
    history: Array.isArray(data.history) ? [...data.history] : []
  };
}

function addFriend(profile, friendId) {
  friendId = String(friendId);
  if (!friendId || friendId === profile.id) throw new Error("دوست نامعتبر است");
  if (!profile.friends.includes(friendId)) profile.friends.push(friendId);
  return profile;
}

function removeFriend(profile, friendId) {
  profile.friends = profile.friends.filter(id => id !== String(friendId));
  return profile;
}

function recordMatch(profile, result) {
  const won = result === "WIN";
  won ? profile.wins++ : profile.losses++;
  profile.rating = Math.max(0, profile.rating + (won ? 20 : -15));
  profile.history.unshift({
    result,
    rating: profile.rating,
    at: Date.now()
  });
  profile.history = profile.history.slice(0, 50);
  return profile;
}

function leaderboard(profiles) {
  return [...profiles]
    .sort((a,b) => b.rating - a.rating)
    .map((p,index) => ({
      rank: index + 1,
      id: p.id,
      name: p.name,
      rating: p.rating,
      wins: p.wins,
      losses: p.losses
    }));
}

module.exports = {
  createProfile,
  addFriend,
  removeFriend,
  recordMatch,
  leaderboard
};
