// Hokm Online v26 — PostgreSQL integration
const { Pool } = require("pg");
const crypto = require("crypto");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.DB_POOL_SIZE || 10),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000
});

async function healthCheck() {
  const r = await pool.query("SELECT NOW() AS now");
  return r.rows[0];
}

async function findUser(username) {
  const r = await pool.query(
    `SELECT id, username, display_name, password_hash, password_salt
     FROM users WHERE username=$1`,
    [String(username).trim().toLowerCase()]
  );
  return r.rows[0] || null;
}

async function createUser(user) {
  const id = user.id || crypto.randomUUID();
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const r = await client.query(
      `INSERT INTO users
       (id, username, display_name, password_hash, password_salt)
       VALUES($1,$2,$3,$4,$5)
       RETURNING id, username, display_name, created_at`,
      [id,user.username,user.displayName,user.passwordHash,user.salt]
    );
    await client.query(
      `INSERT INTO player_stats(user_id)
       VALUES($1) ON CONFLICT (user_id) DO NOTHING`, [id]
    );
    await client.query("COMMIT");
    return r.rows[0];
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}

async function recordGame(game) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // Idempotent: a reconnect/retry cannot double-count the same game.
    const exists = await client.query(
      `SELECT 1 FROM game_history WHERE id=$1 FOR UPDATE`,
      [game.id]
    );
    if (exists.rowCount) {
      await client.query("COMMIT");
      return {recorded:false, duplicate:true};
    }

    await client.query(
      `INSERT INTO game_history
       (id,room_code,started_at,finished_at,winner_team,result_json)
       VALUES($1,$2,$3,$4,$5,$6)`,
      [game.id,game.roomCode,game.startedAt,game.finishedAt,
       game.winnerTeam,JSON.stringify(game.result || {})]
    );

    for (const p of game.players) {
      await client.query(
        `INSERT INTO game_players
         (game_id,user_id,team,seat,score,won)
         VALUES($1,$2,$3,$4,$5,$6)`,
        [game.id,p.userId,p.team,p.seat,p.score || 0,Boolean(p.won)]
      );

      await client.query(
        `INSERT INTO player_stats(user_id,games_played,games_won,total_score)
         VALUES($1,1,$2,$3)
         ON CONFLICT(user_id) DO UPDATE SET
           games_played=player_stats.games_played+1,
           games_won=player_stats.games_won+EXCLUDED.games_won,
           total_score=player_stats.total_score+EXCLUDED.total_score,
           updated_at=NOW()`,
        [p.userId,p.won ? 1 : 0,p.score || 0]
      );
    }

    await client.query("COMMIT");
    return {recorded:true, duplicate:false};
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}

async function getStats(userId) {
  const r = await pool.query(
    `SELECT games_played,games_won,total_score,
            CASE WHEN games_played=0 THEN 0
                 ELSE ROUND((games_won::numeric/games_played)*100,2)
            END AS win_rate
     FROM player_stats WHERE user_id=$1`, [userId]
  );
  return r.rows[0] || {
    games_played:0,games_won:0,total_score:0,win_rate:0
  };
}

async function leaderboard(limit=20) {
  const safeLimit = Math.max(1, Math.min(100, Number(limit)||20));
  const r = await pool.query(
    `SELECT u.id,u.username,u.display_name,
            s.games_played,s.games_won,s.total_score,
            CASE WHEN s.games_played=0 THEN 0
                 ELSE ROUND((s.games_won::numeric/s.games_played)*100,2)
            END AS win_rate
     FROM player_stats s
     JOIN users u ON u.id=s.user_id
     ORDER BY s.games_won DESC, s.win_rate DESC, s.total_score DESC
     LIMIT $1`, [safeLimit]
  );
  return r.rows;
}

module.exports = {
  pool, healthCheck, findUser, createUser,
  recordGame, getStats, leaderboard
};
