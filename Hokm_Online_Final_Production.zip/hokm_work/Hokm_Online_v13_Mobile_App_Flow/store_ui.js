const PACKS=[
{id:"STARTER",title:"شروع",coins:1000,price:"رایگان"},
{id:"SMALL",title:"کوچک",coins:12000,price:"قیمت تعیین شود"},
{id:"MEDIUM",title:"متوسط",coins:35000,price:"قیمت تعیین شود"},
{id:"LARGE",title:"بزرگ",coins:80000,price:"قیمت تعیین شود"}];
module.exports={PACKS,getPacks:()=>PACKS};
