function profile(user){const w=user.wins||0,l=user.losses||0;return{name:user.name||"بازیکن",coins:user.coins||0,wins:w,losses:l,winRate:w+l?Math.round(w*100/(w+l)):0}}
module.exports={profile};
