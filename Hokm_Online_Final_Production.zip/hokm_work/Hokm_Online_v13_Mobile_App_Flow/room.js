const MAX_PLAYERS = 4;

function createRoom(host) {
  return { id:`ROOM-${Math.random().toString(36).slice(2,8).toUpperCase()}`, host, status:"WAITING", players:[host], ready:[] };
}
function joinRoom(room, player) {
  if (room.status !== "WAITING") throw new Error("اتاق آماده شروع نیست");
  if (room.players.length >= MAX_PLAYERS) throw new Error("ظرفیت اتاق تکمیل است");
  if (room.players.some(p=>p.id===player.id)) throw new Error("بازیکن قبلاً وارد شده است");
  room.players.push(player); return room;
}
function toggleReady(room, playerId) {
  if (!room.players.some(p=>p.id===playerId)) throw new Error("بازیکن در اتاق نیست");
  const i=room.ready.indexOf(playerId); if(i>=0) room.ready.splice(i,1); else room.ready.push(playerId); return room;
}
function startRoom(room) {
  if(room.players.length!==MAX_PLAYERS) throw new Error("برای شروع بازی ۴ بازیکن لازم است");
  if(room.ready.length!==MAX_PLAYERS) throw new Error("همه بازیکنان باید آماده باشند");
  room.status="PLAYING"; return room;
}
module.exports={MAX_PLAYERS,createRoom,joinRoom,toggleReady,startRoom};
