// Hokm Online v13 - card engine
const SUITS=['♠','♥','♦','♣'];
const RANKS=['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
function createDeck(){return SUITS.flatMap(s=>RANKS.map(r=>({suit:s,rank:r})));}
function shuffle(cards){const a=[...cards];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function deal(game){if(!game||!game.hands||game.hands.length!==4)throw Error('بازی به ۴ بازیکن نیاز دارد');const d=shuffle(createDeck());game.hands.forEach(h=>h.cards=[]);d.forEach((c,i)=>game.hands[i%4].cards.push(c));game.trick=[];game.round=1;game.turn=game.leader||0;game.roundWins=[0,0,0,0];game.phase='PLAYING';return game;}
function same(a,b){return a.suit===b.suit&&a.rank===b.rank;}
function canPlay(hand,card,lead){if(!hand.cards.some(c=>same(c,card)))return false;if(!lead)return true;const has=hand.cards.some(c=>c.suit===lead);return !has||card.suit===lead;}
function value(r){return RANKS.indexOf(r);}
function winnerOfTrick(trick,lead,trump){let best=trick[0];for(const p of trick.slice(1)){const a=p.card,b=best.card,at=a.suit===trump,bt=b.suit===trump,al=a.suit===lead,bl=b.suit===lead;if((at&&!bt)||(at===bt&&al&&!bl)||(at===bt&&al===bl&&value(a.rank)>value(b.rank)))best=p;}return best.playerIndex;}
function playCard(game,player,card){if(game.turn!==player)throw Error('نوبت این بازیکن نیست');const h=game.hands[player],lead=game.trick.length?game.trick[0].card.suit:null;if(!canPlay(h,card,lead))throw Error('این کارت مجاز نیست');h.cards.splice(h.cards.findIndex(c=>same(c,card)),1);game.trick.push({playerIndex:player,card});if(game.trick.length<4){game.turn=(player+1)%4;return {complete:false};}const w=winnerOfTrick(game.trick,lead,game.trump);game.roundWins[w]++;game.leader=w;game.turn=w;game.trick=[];if(game.round>=13){game.phase='FINISHED';return {complete:true,winner:w,finished:true};}game.round++;return {complete:true,winner:w,finished:false};}
module.exports={SUITS,RANKS,createDeck,shuffle,deal,canPlay,winnerOfTrick,playCard};
