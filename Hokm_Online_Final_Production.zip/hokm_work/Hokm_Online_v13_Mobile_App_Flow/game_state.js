const SUITS=["♠","♥","♦","♣"];
function createGame(room){
 if(!room||room.players.length!==4) throw new Error("بازی به ۴ بازیکن نیاز دارد");
 return {roomId:room.id,phase:"TRUMP",turn:0,round:1,leader:0,trump:null,teamScores:[0,0],hands:room.players.map(p=>({playerId:p.id,cards:[]})),winner:null};
}
function setTrump(game,suit){if(!SUITS.includes(suit)) throw new Error("خال حکم نامعتبر است"); if(game.phase!=="TRUMP") throw new Error("مرحله تعیین حکم تمام شده است"); game.trump=suit; game.phase="PLAYING"; return game;}
function nextTurn(game){game.turn=(game.turn+1)%4; return game;}
function scoreTeam(game,team,points=1){if(![0,1].includes(team)||!Number.isInteger(points)||points<1) throw new Error("امتیاز نامعتبر است"); game.teamScores[team]+=points; if(game.teamScores[team]>=7){game.winner=team;game.phase="FINISHED";} return game;}
module.exports={SUITS,createGame,setTrump,nextTurn,scoreTeam};
