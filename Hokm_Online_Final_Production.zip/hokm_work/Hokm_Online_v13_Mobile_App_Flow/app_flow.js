const SCREENS=["LOGIN","LOBBY","ROOM","GAME","STORE","PROFILE"];
const transitions={LOGIN:["LOBBY"],LOBBY:["ROOM","STORE","PROFILE"],ROOM:["GAME","LOBBY"],GAME:["LOBBY","STORE"],STORE:["LOBBY"],PROFILE:["LOBBY"]};
const canNavigate=(from,to)=>(transitions[from]||[]).includes(to);
module.exports={SCREENS,transitions,canNavigate};
