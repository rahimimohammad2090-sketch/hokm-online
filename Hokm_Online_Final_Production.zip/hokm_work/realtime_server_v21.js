// Hokm Online v21
// WebSocket + موتور بازی

const http = require("http");
const WebSocket = require("ws");
const {newGame, deal, play} = require("./v21_game_engine");

const PORT = process.env.PORT || 3000;
const rooms = new Map();

function code() {
  return Math.random().toString(36).slice(2,8).toUpperCase();
}

function broadcast(room, message) {
  const data = JSON.stringify(message);
  for (const p of room.players) {
    if (p.socket && p.socket.readyState === WebSocket.OPEN) p.socket.send(data);
  }
}

function publicState(room) {
  const g = room.game;
  return {
    code: room.code,
    status: room.status,
    players: room.players.map(p => ({
      id:p.id, name:p.name, connected:p.connected, ready:p.ready
    })),
    game: g ? {
      phase:g.phase,
      turn:g.turn,
      round:g.round,
      trump:g.trump,
      roundWins:g.roundWins,
      trick:g.trick
    } : null
  };
}

function startGame(room) {
  room.game = deal(newGame());
  room.status = "PLAYING";
}

const server = http.createServer((req,res) => {
  if (req.url === "/health") {
    res.writeHead(200, {"Content-Type":"application/json"});
    res.end(JSON.stringify({ok:true, version:"21v"}));
    return;
  }
  res.writeHead(404);
  res.end();
});

const wss = new WebSocket.Server({server});

wss.on("connection", socket => {
  let room = null;
  let playerId = null;

  socket.on("message", raw => {
    try {
      const m = JSON.parse(raw.toString());

      if (m.type === "CREATE_ROOM") {
        playerId = String(m.playerId);
        room = {
          code: code(),
          status:"WAITING",
          players:[{id:playerId,name:m.name||"بازیکن",connected:true,ready:false,socket}],
          game:null
        };
        rooms.set(room.code, room);
        socket.send(JSON.stringify({type:"ROOM_CREATED",room:publicState(room)}));
        return;
      }

      if (m.type === "JOIN_ROOM") {
        room = rooms.get(String(m.code).toUpperCase());
        if (!room) throw new Error("ROOM_NOT_FOUND");
        if (room.players.length >= 4) throw new Error("ROOM_FULL");
        playerId = String(m.playerId);
        room.players.push({
          id:playerId,name:m.name||"بازیکن",connected:true,ready:false,socket
        });
        broadcast(room,{type:"ROOM_STATE",room:publicState(room)});
        return;
      }

      if (!room) throw new Error("NOT_IN_ROOM");

      const me = room.players.find(p => p.id === playerId);

      if (m.type === "READY") {
        me.ready = Boolean(m.value);
        if (room.players.length === 4 && room.players.every(p=>p.ready)) {
          startGame(room);
          broadcast(room,{type:"GAME_STARTED",room:publicState(room)});
        } else {
          broadcast(room,{type:"ROOM_STATE",room:publicState(room)});
        }
        return;
      }

      if (m.type === "SET_TRUMP") {
        if (!room.game) throw new Error("GAME_NOT_STARTED");
        if (me !== room.players[0]) throw new Error("NOT_HAKEM");
        if (!["♠","♥","♦","♣"].includes(m.trump)) throw new Error("INVALID_TRUMP");
        room.game.trump = m.trump;
        broadcast(room,{type:"TRUMP_SET",room:publicState(room)});
        return;
      }

      if (m.type === "PLAY_CARD") {
        if (!room.game) throw new Error("GAME_NOT_STARTED");
        const result = play(room.game, room.players.findIndex(p=>p.id===playerId), m.card);
        broadcast(room,{
          type:"CARD_PLAYED",
          playerId,
          card:m.card,
          result,
          room:publicState(room)
        });
        return;
      }

      if (m.type === "PING") {
        socket.send(JSON.stringify({type:"PONG",at:Date.now()}));
        return;
      }

      throw new Error("UNKNOWN_MESSAGE");
    } catch (e) {
      socket.send(JSON.stringify({type:"ERROR",message:e.message}));
    }
  });

  socket.on("close", () => {
    if (!room || !playerId) return;
    const p = room.players.find(x=>x.id===playerId);
    if (p) {
      p.connected = false;
      p.socket = null;
      broadcast(room,{type:"ROOM_STATE",room:publicState(room)});
    }
  });
});

server.listen(PORT,()=>console.log("Hokm Online v21 running on",PORT));
