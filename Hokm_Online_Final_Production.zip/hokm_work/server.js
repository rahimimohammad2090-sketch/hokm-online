// Hokm Online v19 - نمونه هسته سرور
// این فایل یک اسکلت اجرایی برای اتصال کلاینت‌هاست.
// برای تولید واقعی باید احراز هویت، دیتابیس و TLS اضافه شوند.

const http = require("http");

const rooms = new Map();

function roomCode() {
  return Math.random().toString(36).slice(2,8).toUpperCase();
}

function createRoom(host) {
  let id;
  do { id = roomCode(); } while (rooms.has(id));

  const room = {
    id,
    host,
    players: [{id: host, connected: true, ready: false}],
    status: "WAITING",
    createdAt: Date.now()
  };

  rooms.set(id, room);
  return room;
}

function joinRoom(id, playerId) {
  const room = rooms.get(id);
  if (!room) throw new Error("اتاق پیدا نشد");
  if (room.players.length >= 4) throw new Error("ظرفیت اتاق تکمیل است");
  if (room.players.some(p => p.id === playerId)) {
    throw new Error("بازیکن قبلاً وارد اتاق شده است");
  }

  room.players.push({id: playerId, connected: true, ready: false});
  return room;
}

function publicRoom(room) {
  return {
    id: room.id,
    status: room.status,
    players: room.players.map(p => ({
      id: p.id,
      connected: p.connected,
      ready: p.ready
    }))
  };
}

const server = http.createServer((req, res) => {
  res.setHeader("Content-Type", "application/json; charset=utf-8");

  if (req.url === "/health") {
    res.end(JSON.stringify({ok:true, service:"hokm-online", version:"19v"}));
    return;
  }

  res.statusCode = 404;
  res.end(JSON.stringify({error:"Not Found"}));
});

server.listen(process.env.PORT || 3000, () => {
  console.log("Hokm Online v19 server started");
});

module.exports = {rooms, createRoom, joinRoom, publicRoom};
