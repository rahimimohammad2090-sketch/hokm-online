const assert=require('assert');
const {checkReadiness}=require('./v37_readiness');
const {createHealthServer}=require('./v37_health_server');
const http=require('http');

(async()=>{
 const base={AUTH_SECRET:'x'.repeat(48),NODE_ENV:'production',TLS_ENABLED:'true',PERSISTENCE_DRIVER:'postgres',REDIS_ENABLED:'true'};
 let r=checkReadiness({env:base,persistence:{connected:true}});
 assert.equal(r.ok,true); assert.equal(r.status,'ready');
 r=checkReadiness({env:base,persistence:null});
 assert.equal(r.ok,false); assert.equal(r.checks.persistence.error,'PERSISTENCE_NOT_CONNECTED');
 r=checkReadiness({env:{...base,TLS_ENABLED:'false'},persistence:{connected:true}});
 assert.equal(r.ok,false); assert.equal(r.checks.config.error,'TLS_REQUIRED');
 const server=createHealthServer({env:base,persistence:{connected:true},version:'production'});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const port=server.address().port;
 const get=path=>new Promise((resolve,reject)=>http.get({host:'127.0.0.1',port,path},res=>{let b='';res.on('data',x=>b+=x);res.on('end',()=>resolve({status:res.statusCode,body:JSON.parse(b)}));}).on('error',reject));
 let h=await get('/health'); assert.equal(h.status,200); assert.equal(h.body.status,'alive');
 h=await get('/ready'); assert.equal(h.status,200); assert.equal(h.body.status,'ready');
 h=await get('/missing'); assert.equal(h.status,404);
 await new Promise(resolve=>server.close(resolve));
 console.log('v37 readiness + health endpoint tests: PASS');
})().catch(e=>{console.error(e);process.exit(1)});
