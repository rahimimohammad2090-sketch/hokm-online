// v30 — start the Hokm engine from a STARTED v29 room

const {HokmGame} = require("./v30_hokm_engine");

function createGameFromRoom(room) {
  if (!room || room.status !== "STARTED") {
    throw new Error("ROOM_NOT_STARTED");
  }
  if (!Array.isArray(room.players) || room.players.length !== 4) {
    throw new Error("ROOM_REQUIRES_4_PLAYERS");
  }

  const players = room.players.slice().sort((a,b)=>a.seat-b.seat);
  players.forEach((p,i)=>{
    if (p.seat !== i) throw new Error("INVALID_SEAT_LAYOUT");
  });

  const game = new HokmGame({
    matchId:room.matchId,
    players
  });

  game.start();
  return game;
}

module.exports = {createGameFromRoom};
