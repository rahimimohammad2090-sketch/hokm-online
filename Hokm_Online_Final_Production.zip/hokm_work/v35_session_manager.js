const crypto=require("crypto");
class SessionManager{constructor({ttlMs=3600000}={}){this.ttlMs=ttlMs;this.sessions=new Map()}
create(userId,role="player"){const id=crypto.randomBytes(24).toString("hex");this.sessions.set(id,{userId,role,createdAt:Date.now(),lastSeen:Date.now()});return id}
get(id,now=Date.now()){const s=this.sessions.get(id);if(!s||now-s.lastSeen>this.ttlMs){if(s)this.sessions.delete(id);return null}s.lastSeen=now;return {...s}}
revoke(id){return this.sessions.delete(id)} revokeUser(u){let n=0;for(const[id,s]of this.sessions)if(s.userId===u){this.sessions.delete(id);n++}return n}}
module.exports={SessionManager};