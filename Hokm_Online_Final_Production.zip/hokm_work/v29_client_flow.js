AUTH -> FIND_MATCH -> QUEUED -> ROOM_ASSIGNED -> JOIN_ASSIGNED_ROOM -> ROOM_JOINED -> ROOM_STATUS -> START_IF_READY -> GAME_READY -> Hokm engine.
Security: client never chooses seat; joinToken never in URL or logs.
