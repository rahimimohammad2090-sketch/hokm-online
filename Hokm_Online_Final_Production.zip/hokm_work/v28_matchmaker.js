// Hokm Online v28 — in-process matchmaking core
const crypto=require("crypto");

class Matchmaker {
  constructor({matchSize=4, baseRange=100, rangePerSecond=10, maxWait=120}={}) {
    this.matchSize=matchSize; this.baseRange=baseRange;
    this.rangePerSecond=rangePerSecond; this.maxWait=maxWait;
    this.queue=new Map(); // userId -> ticket
  }

  join(user, mode="classic") {
    if(this.queue.has(user.id)) throw new Error("ALREADY_QUEUED");
    const ticket={
      ticketId:crypto.randomUUID(), userId:user.id,
      name:user.displayName, rating:Number(user.rating)||1000,
      mode, createdAt:Date.now(), status:"queued"
    };
    this.queue.set(user.id,ticket);
    return ticket;
  }

  cancel(userId) {
    const t=this.queue.get(userId);
    if(!t) return false;
    this.queue.delete(userId);
    t.status="cancelled";
    return true;
  }

  range(ticket, now=Date.now()) {
    const waited=Math.min(this.maxWait,(now-ticket.createdAt)/1000);
    return this.baseRange + Math.floor(waited*this.rangePerSecond);
  }

  findMatch(now=Date.now()) {
    const all=[...this.queue.values()]
      .filter(t=>t.status==="queued")
      .sort((a,b)=>a.createdAt-b.createdAt);

    for(const anchor of all) {
      const range=this.range(anchor,now);
      const candidates=all.filter(t=>
        t.mode===anchor.mode &&
        Math.abs(t.rating-anchor.rating)<=Math.max(range,this.range(t,now))
      );
      if(candidates.length>=this.matchSize) {
        const players=candidates.slice(0,this.matchSize);
        players.forEach(p=>this.queue.delete(p.userId));
        const match={
          matchId:crypto.randomUUID(),
          mode:anchor.mode,
          createdAt:now,
          players
        };
        players.forEach(p=>p.status="matched");
        return match;
      }
    }
    return null;
  }

  snapshot() {
    return [...this.queue.values()].map(t=>({
      ticketId:t.ticketId,userId:t.userId,mode:t.mode,
      rating:t.rating,waitSeconds:Math.floor((Date.now()-t.createdAt)/1000)
    }));
  }
}
module.exports={Matchmaker};
