// Hokm Online v18
// امنیت، اعتبارسنجی حرکت، ذخیره وضعیت و بازیابی اتصال

function safeClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function validatePlayerId(id) {
  return typeof id === "string" && id.length >= 1 && id.length <= 64;
}

function validateRoomCode(code) {
  return typeof code === "string" && /^[A-Z0-9]{6}$/.test(code);
}

function validateMove(game, playerIndex, card) {
  if (!game || game.phase !== "PLAYING") {
    return {ok:false, reason:"GAME_NOT_PLAYING"};
  }
  if (!Number.isInteger(playerIndex) || playerIndex < 0 || playerIndex >= 4) {
    return {ok:false, reason:"INVALID_PLAYER"};
  }
  if (game.turn !== playerIndex) {
    return {ok:false, reason:"NOT_YOUR_TURN"};
  }
  if (!card || typeof card.suit !== "string" || typeof card.rank !== "string") {
    return {ok:false, reason:"INVALID_CARD"};
  }
  return {ok:true};
}

function createCheckpoint(game) {
  return {
    version: 18,
    savedAt: Date.now(),
    game: safeClone(game)
  };
}

function restoreCheckpoint(checkpoint) {
  if (!checkpoint || checkpoint.version !== 18 || !checkpoint.game) {
    throw new Error("ذخیره بازی نامعتبر است");
  }
  return safeClone(checkpoint.game);
}

function reconnectPlayer(room, playerId) {
  if (!validatePlayerId(String(playerId))) {
    throw new Error("شناسه بازیکن نامعتبر است");
  }
  const player = room.players.find(p => p.id === String(playerId));
  if (!player) throw new Error("بازیکن در اتاق وجود ندارد");
  player.connected = true;
  return player;
}

function disconnectPlayer(room, playerId) {
  const player = room.players.find(p => p.id === String(playerId));
  if (player) player.connected = false;
  return room;
}

function auditEvent(type, actorId, details = {}) {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2,8)}`,
    type,
    actorId: String(actorId),
    details,
    at: Date.now()
  };
}

module.exports = {
  safeClone,
  validatePlayerId,
  validateRoomCode,
  validateMove,
  createCheckpoint,
  restoreCheckpoint,
  reconnectPlayer,
  disconnectPlayer,
  auditEvent
};
