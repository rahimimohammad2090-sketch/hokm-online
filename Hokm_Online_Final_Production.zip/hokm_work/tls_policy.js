const fs=require('fs');
function validateTlsConfig(env=process.env){
  if(env.NODE_ENV!=='production') return {ok:true,required:false};
  if(env.TLS_ENABLED!=='true') return {ok:false,error:'TLS_REQUIRED'};
  for(const [key,label] of [['TLS_CERT_FILE','TLS_CERT'],['TLS_KEY_FILE','TLS_KEY']]){
    const p=env[key]; if(!p) return {ok:false,error:`${label}_FILE_REQUIRED`};
    try{ if(!fs.statSync(p).isFile()) return {ok:false,error:`${label}_FILE_INVALID`}; }
    catch(e){ return {ok:false,error:`${label}_FILE_UNREADABLE`}; }
  }
  return {ok:true,required:true};
}
module.exports={validateTlsConfig};
