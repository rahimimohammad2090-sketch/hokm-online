// Hokm Online v23 client
// رابط UI به WebSocket سرور

class HokmOnlineClient {
  constructor(url, ui) {
    this.url = url;
    this.ui = ui;
    this.ws = null;
    this.state = null;
    this.hand = [];
    this.playerIndex = null;
  }

  connect() {
    this.ws = new WebSocket(this.url);

    this.ws.onopen = () => this.ui.status("متصل شد");
    this.ws.onclose = () => this.ui.status("ارتباط قطع شد");
    this.ws.onerror = () => this.ui.status("خطا در ارتباط");

    this.ws.onmessage = event => {
      const msg = JSON.parse(event.data);

      if (msg.type === "ERROR") {
        this.ui.error(msg.message);
        return;
      }

      if (msg.type === "GAME_STATE") {
        this.state = msg.room;
        this.hand = msg.hand || [];
        this.playerIndex = msg.playerIndex;
        this.ui.render(this.state, this.hand, this.playerIndex);
        return;
      }

      if (msg.type === "ROOM_STATE" || msg.type === "ROOM_CREATED") {
        this.state = msg.room;
        this.ui.render(this.state, this.hand, this.playerIndex);
        return;
      }

      if (msg.type === "TRICK_UPDATE") {
        this.ui.trickUpdate(msg);
      }

      if (msg.type === "GAME_FINISHED") {
        this.state = msg.room;
        this.ui.gameFinished(this.state);
      }
    };
  }

  send(type, payload={}) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN)
      throw new Error("اتصال برقرار نیست");
    this.ws.send(JSON.stringify({type, ...payload}));
  }

  createRoom(playerId, name) {
    this.send("CREATE_ROOM",{playerId,name});
  }

  joinRoom(code, playerId, name) {
    this.send("JOIN_ROOM",{code,playerId,name});
  }

  ready(value) {
    this.send("READY",{value});
  }

  setTrump(trump) {
    this.send("SET_TRUMP",{trump});
  }

  playCard(card) {
    // سرور مرجع نهایی قانون است.
    this.send("PLAY_CARD",{card});
  }
}

window.HokmOnlineClient = HokmOnlineClient;
