const http=require("http"),WebSocket=require("ws");const {getSession}=require("./v24_session");const {matchmaker,registry,createRoomsFromQueue}=require("./v29_match_room_bridge");const sockets=new Map();
const send=(s,type,p={})=>{if(s?.readyState===WebSocket.OPEN)s.send(JSON.stringify({type,...p}))};
setInterval(()=>{for(const r of createRoomsFromQueue())for(const p of r.players)send(sockets.get(p.userId),"ROOM_ASSIGNED",{matchId:r.matchId,roomCode:r.roomCode,mode:r.mode,seat:p.seat,joinToken:p.joinToken})},500);
const server=http.createServer((req,res)=>{res.setHeader("Content-Type","application/json; charset=utf-8");if(req.url==="/health")return res.end(JSON.stringify({ok:true,version:"29v"}));res.statusCode=404;res.end(JSON.stringify({error:"NOT_FOUND"}))});
const wss=new WebSocket.Server({server});wss.on("connection",s=>{let user=null,active=null;s.on("message",raw=>{try{const m=JSON.parse(raw);
if(m.type==="AUTH"){user=getSession(m.token);if(!user)throw Error("INVALID_SESSION");sockets.set(user.id,s);return send(s,"AUTHENTICATED",{user})}
if(!user)throw Error("AUTH_REQUIRED");
if(m.type==="FIND_MATCH"){const t=matchmaker.join(user,m.mode||"classic");return send(s,"QUEUED",{ticketId:t.ticketId,mode:t.mode,rating:t.rating})}
if(m.type==="CANCEL_MATCH"){matchmaker.cancel(user.id);return send(s,"MATCH_CANCELLED")}
if(m.type==="JOIN_ASSIGNED_ROOM"){const j=registry.consumeJoin(m.matchId,user.id,m.joinToken);active=j.matchId;return send(s,"ROOM_JOINED",j)}
if(m.type==="ROOM_STATUS"){const r=registry.publicRoom(m.matchId);if(!r)throw Error("ROOM_NOT_FOUND");return send(s,"ROOM_STATUS",r)}
if(m.type==="START_IF_READY")return send(s,"GAME_READY",registry.startRoom(m.matchId));
throw Error("UNKNOWN_MESSAGE")}catch(e){send(s,"ERROR",{message:e.message||"SERVER_ERROR"})}});
s.on("close",()=>{if(user){matchmaker.cancel(user.id);sockets.delete(user.id);if(active)registry.disconnect(active,user.id)}})});
server.listen(process.env.GAME_PORT||3003,()=>console.log("Hokm Online v29 ready"));
