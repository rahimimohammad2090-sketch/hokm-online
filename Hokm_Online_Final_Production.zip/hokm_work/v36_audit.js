class AuditLog {
  constructor({ maxEntries = 10000 } = {}) {
    this.maxEntries = maxEntries;
    this.entries = [];
  }
  record({ userId = null, actionId = null, type = null, status, error = null, ts = Date.now() }) {
    const entry = { id: `${ts}-${this.entries.length}`, userId, actionId, type, status, error, ts };
    this.entries.push(entry);
    if (this.entries.length > this.maxEntries) this.entries.shift();
    return { ...entry };
  }
  list() { return this.entries.map(x => ({ ...x })); }
}
module.exports = { AuditLog };
