Hokm Online v36 — Secure Action Gateway & Realtime Integration
v36 روی v35 ساخته شده است و احراز هویت HMAC، session TTL، RBAC، مالکیت صندلی، sanitization و اعتبارسنجی action را به یک دروازه واحد برای عملیات بازی متصل می‌کند.
قابلیت‌های اصلی:
- SecureActionGateway برای authenticate + session + permission + seat ownership + sequence/idempotency
- اتصال کنترل‌شده به persistence v34 برای ثبت actionهای پذیرفته‌شده
- جلوگیری از replay با actionId و sequence
- محدودسازی نوع و اندازه payload
- audit event برای قبول/رد عملیات
- تست‌های یکپارچه v36
