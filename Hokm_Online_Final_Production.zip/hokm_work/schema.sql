-- Hokm Online v25
-- PostgreSQL persistent data model

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY,
  username VARCHAR(24) UNIQUE NOT NULL,
  display_name VARCHAR(40) NOT NULL,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS player_stats (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  games_played INTEGER NOT NULL DEFAULT 0,
  games_won INTEGER NOT NULL DEFAULT 0,
  total_score BIGINT NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS game_history (
  id UUID PRIMARY KEY,
  room_code VARCHAR(6) NOT NULL,
  started_at TIMESTAMPTZ NOT NULL,
  finished_at TIMESTAMPTZ,
  winner_team SMALLINT,
  result_json JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS game_players (
  game_id UUID REFERENCES game_history(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  team SMALLINT NOT NULL,
  seat SMALLINT NOT NULL,
  score INTEGER NOT NULL DEFAULT 0,
  won BOOLEAN NOT NULL DEFAULT FALSE,
  PRIMARY KEY (game_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_game_history_started_at ON game_history(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_game_players_user_id ON game_players(user_id);
