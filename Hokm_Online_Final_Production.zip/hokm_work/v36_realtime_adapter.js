const { SecureActionGateway } = require("./v36_action_gateway");
const { AuditLog } = require("./v36_audit");

class RealtimeSecureAdapter {
  constructor({ auth, sessions, store = null, audit = new AuditLog() } = {}) {
    this.gateway = new SecureActionGateway({ auth, sessions, store });
    this.audit = audit;
  }

  async handle({ token, action, apply, now = Date.now() }) {
    const result = await this.gateway.execute({ token, action, now, apply });
    this.audit.record({
      userId: result.userId || null,
      actionId: action && action.actionId || null,
      type: action && action.type || null,
      status: result.ok ? "ACCEPT" : "REJECT",
      error: result.ok ? null : result.error,
      ts: now
    });
    return result;
  }
}
module.exports = { RealtimeSecureAdapter };
