// Hokm Online v14
// امتیازدهی کامل، پایان دست و تعیین برنده بازی

const TARGET_SCORE = 7;

function teamOfPlayer(playerIndex) {
  return playerIndex % 2; // 0,2 = تیم 0 | 1,3 = تیم 1
}

function createScoreState() {
  return {
    teamRounds: [0, 0],
    teamGames: [0, 0],
    handNumber: 1,
    matchFinished: false,
    winnerTeam: null
  };
}

function scoreTrick(state, winningPlayer) {
  const team = teamOfPlayer(winningPlayer);
  state.teamRounds[team]++;
  return state;
}

function finishHand(state) {
  const a = state.teamRounds[0];
  const b = state.teamRounds[1];

  if (a === b) {
    return { finished: false, winnerTeam: null, score: [a,b] };
  }

  const winner = a > b ? 0 : 1;
  state.teamGames[winner]++;
  state.teamRounds = [0, 0];
  state.handNumber++;

  if (state.teamGames[winner] >= TARGET_SCORE) {
    state.matchFinished = true;
    state.winnerTeam = winner;
  }

  return {
    finished: true,
    winnerTeam: winner,
    score: [...state.teamGames],
    matchFinished: state.matchFinished
  };
}

function resultText(winnerTeam) {
  if (winnerTeam === 0) return "تیم ۱ برنده شد";
  if (winnerTeam === 1) return "تیم ۲ برنده شد";
  return "بازی ادامه دارد";
}

module.exports = {
  TARGET_SCORE,
  teamOfPlayer,
  createScoreState,
  scoreTrick,
  finishHand,
  resultText
};
