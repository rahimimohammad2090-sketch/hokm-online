// Hokm Online v28 — WebSocket matchmaking
const http=require("http");
const WebSocket=require("ws");
const crypto=require("crypto");
const {getSession}=require("./v24_session");
const {Matchmaker}=require("./v28_matchmaker");

const mm=new Matchmaker({matchSize:4,baseRange:100,rangePerSecond:10,maxWait:120});
const sockets=new Map();
const matches=new Map();

function send(s,type,payload={}) {
  if(s?.readyState===WebSocket.OPEN) s.send(JSON.stringify({type,...payload}));
}
function tick(){
  let match;
  while((match=mm.findMatch())){
    matches.set(match.matchId,match);
    match.players.forEach((p,i)=>{
      const s=sockets.get(p.userId);
      send(s,"MATCH_FOUND",{
        matchId:match.matchId,
        mode:match.mode,
        seat:i,
        players:match.players.map(x=>({id:x.userId,name:x.name,rating:x.rating}))
      });
    });
  }
}
setInterval(tick,500);

const server=http.createServer((req,res)=>{
  res.setHeader("Content-Type","application/json; charset=utf-8");
  if(req.url==="/health") return res.end(JSON.stringify({ok:true,version:"28v"}));
  if(req.url==="/matchmaking/status")
    return res.end(JSON.stringify({queued:mm.snapshot().length}));
  res.statusCode=404; res.end(JSON.stringify({error:"NOT_FOUND"}));
});

const wss=new WebSocket.Server({server});
wss.on("connection",socket=>{
  let user=null;
  socket.on("message",raw=>{
    try{
      const m=JSON.parse(raw.toString());
      if(m.type==="AUTH"){
        user=getSession(m.token);
        if(!user) throw new Error("INVALID_SESSION");
        sockets.set(user.id,socket);
        return send(socket,"AUTHENTICATED",{user});
      }
      if(!user) throw new Error("AUTH_REQUIRED");

      if(m.type==="FIND_MATCH"){
        const ticket=mm.join(user,m.mode||"classic");
        return send(socket,"QUEUED",{
          ticketId:ticket.ticketId,
          mode:ticket.mode,
          rating:ticket.rating,
          position:mm.snapshot().findIndex(x=>x.userId===user.id)+1
        });
      }
      if(m.type==="CANCEL_MATCH"){
        mm.cancel(user.id);
        return send(socket,"MATCH_CANCELLED");
      }
      if(m.type==="QUEUE_STATUS"){
        const t=mm.snapshot().find(x=>x.userId===user.id);
        return send(socket,"QUEUE_STATUS",{queued:Boolean(t),ticket:t||null});
      }
      throw new Error("UNKNOWN_MESSAGE");
    }catch(e){send(socket,"ERROR",{message:e.message||"SERVER_ERROR"});}
  });
  socket.on("close",()=>{
    if(user){ mm.cancel(user.id); sockets.delete(user.id); }
  });
});
server.listen(process.env.MM_PORT||3002,()=>console.log("Hokm Online v28 matchmaking ready"));
