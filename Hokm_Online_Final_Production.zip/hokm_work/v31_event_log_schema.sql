-- v31 event log contract
CREATE TABLE IF NOT EXISTS game_events (
  event_id BIGSERIAL PRIMARY KEY,
  match_id UUID NOT NULL,
  event_type VARCHAR(40) NOT NULL,
  seat SMALLINT,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_game_events_match_time
  ON game_events(match_id, created_at, event_id);
