#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
OUT=${1:-./backups}
mkdir -p "$OUT"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
FILE="$OUT/hokm_${STAMP}.dump"
docker compose -f docker-compose.production.yml exec -T postgres sh -c 'pg_dump -U hokm -d hokm -Fc' > "$FILE"
test -s "$FILE"
sha256sum "$FILE" > "$FILE.sha256"
echo "Backup created: $FILE"
