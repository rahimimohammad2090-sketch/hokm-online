#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
FILE=${1:-}
[ -n "$FILE" ] || { echo 'Usage: ops/restore_postgres.sh <backup.dump>'; exit 2; }
[ -s "$FILE" ] || { echo 'ERROR: backup file not found'; exit 1; }
docker compose -f docker-compose.production.yml exec -T postgres sh -c 'pg_restore -U hokm -d hokm --clean --if-exists --no-owner' < "$FILE"
echo 'Restore completed.'
