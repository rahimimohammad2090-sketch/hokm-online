#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
command -v docker >/dev/null 2>&1 || { echo 'ERROR: docker is required'; exit 1; }
docker compose version >/dev/null 2>&1 || { echo 'ERROR: docker compose is required'; exit 1; }
[ -s secrets/auth_secret ] || { echo 'ERROR: secrets/auth_secret missing'; exit 1; }
[ -s secrets/postgres_password ] || { echo 'ERROR: secrets/postgres_password missing'; exit 1; }
[ -s secrets/tls_cert.pem ] || { echo 'ERROR: secrets/tls_cert.pem missing'; exit 1; }
[ -s secrets/tls_key.pem ] || { echo 'ERROR: secrets/tls_key.pem missing'; exit 1; }
chmod 600 secrets/*
printf '%s\n' 'Production preflight: PASS'
