#!/bin/sh
set -eu
BASE=${BASE_URL:-https://127.0.0.1:3000}
code=$(curl -ksS -o /tmp/hokm_health.json -w '%{http_code}' "$BASE/health")
[ "$code" = 200 ] || { cat /tmp/hokm_health.json; exit 1; }
code=$(curl -ksS -o /tmp/hokm_ready.json -w '%{http_code}' "$BASE/ready")
[ "$code" = 200 ] || { cat /tmp/hokm_ready.json; exit 1; }
printf '%s\n' 'Production smoke test: PASS'
