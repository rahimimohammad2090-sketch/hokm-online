const crypto=require("crypto"); const rooms=new Map();
const code=()=>{let x;do{x=crypto.randomBytes(4).toString("hex").slice(0,6).toUpperCase()}while([...rooms.values()].some(r=>r.roomCode===x));return x};
const tok=()=>crypto.randomBytes(32).toString("hex");
const hash=x=>crypto.createHash("sha256").update(x).digest("hex");
function createRoom(match){if(!match||match.players.length!==4)throw Error("MATCH_REQUIRES_4_PLAYERS");if(rooms.has(match.matchId))return rooms.get(match.matchId);
 const r={matchId:match.matchId,roomCode:code(),mode:match.mode||"classic",status:"WAITING_FOR_PLAYERS",createdAt:Date.now(),startedAt:null,players:[]};
 match.players.forEach((p,seat)=>{const t=tok();r.players.push({userId:p.userId,name:p.name,rating:p.rating,seat,joinTokenHash:hash(t),joinToken:t,connected:false,joinedAt:null})});rooms.set(r.matchId,r);return r}
function consumeJoin(id,uid,t){const r=rooms.get(id);if(!r)throw Error("ROOM_NOT_FOUND");const p=r.players.find(x=>x.userId===uid);if(!p)throw Error("PLAYER_NOT_ASSIGNED");if(!p.joinToken)throw Error("JOIN_TOKEN_ALREADY_USED");if(hash(t)!==p.joinTokenHash)throw Error("INVALID_JOIN_TOKEN");p.joinToken=null;p.joinTokenHash=null;p.connected=true;p.joinedAt=Date.now();if(r.players.every(x=>x.connected))r.status="READY_TO_START";return {matchId:r.matchId,roomCode:r.roomCode,mode:r.mode,seat:p.seat,status:r.status}}
function disconnect(id,uid){const r=rooms.get(id);if(!r)return false;const p=r.players.find(x=>x.userId===uid);if(!p)return false;p.connected=false;if(r.status!=="STARTED"&&r.status!=="FINISHED")r.status="WAITING_FOR_PLAYERS";return true}
function startRoom(id){const r=rooms.get(id);if(!r)throw Error("ROOM_NOT_FOUND");if(r.status!=="READY_TO_START")throw Error("ROOM_NOT_READY");r.status="STARTED";r.startedAt=Date.now();return {matchId:r.matchId,roomCode:r.roomCode,mode:r.mode,players:r.players.slice().sort((a,b)=>a.seat-b.seat).map(p=>({userId:p.userId,name:p.name,seat:p.seat}))}}
function publicRoom(id){const r=rooms.get(id);if(!r)return null;return {matchId:r.matchId,roomCode:r.roomCode,mode:r.mode,status:r.status,players:r.players.map(p=>({userId:p.userId,name:p.name,seat:p.seat,connected:p.connected}))}}
module.exports={rooms,createRoom,consumeJoin,disconnect,startRoom,publicRoom};
