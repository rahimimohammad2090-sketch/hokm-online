// Hokm Online v20
// WebSocket realtime multiplayer skeleton

const http = require("http");
const WebSocket = require("ws");

const PORT = process.env.PORT || 3000;
const rooms = new Map();

function makeCode() {
  let code;
  do {
    code = Math.random().toString(36).slice(2, 8).toUpperCase();
  } while (rooms.has(code));
  return code;
}

function publicState(room) {
  return {
    code: room.code,
    status: room.status,
    players: room.players.map(p => ({
      id: p.id,
      name: p.name,
      connected: p.connected,
      ready: p.ready
    })),
    turn: room.game ? room.game.turn : null,
    round: room.game ? room.game.round : null,
    trump: room.game ? room.game.trump : null
  };
}

function broadcast(room, message) {
  const payload = JSON.stringify(message);
  for (const player of room.players) {
    if (player.socket && player.socket.readyState === WebSocket.OPEN) {
      player.socket.send(payload);
    }
  }
}

function createRoom(player) {
  const room = {
    code: makeCode(),
    status: "WAITING",
    players: [player],
    game: null
  };
  rooms.set(room.code, room);
  return room;
}

function findPlayer(room, id) {
  return room.players.find(p => p.id === id);
}

function joinRoom(room, player) {
  if (room.status !== "WAITING") throw new Error("اتاق در حال بازی است");
  if (room.players.length >= 4) throw new Error("ظرفیت اتاق تکمیل است");
  if (findPlayer(room, player.id)) throw new Error("بازیکن قبلاً وارد شده است");
  room.players.push(player);
}

function sendError(socket, message) {
  socket.send(JSON.stringify({type:"ERROR", message}));
}

const httpServer = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, {"Content-Type":"application/json"});
    res.end(JSON.stringify({ok:true, version:"20v"}));
    return;
  }
  res.writeHead(404);
  res.end();
});

const wss = new WebSocket.Server({server: httpServer});

wss.on("connection", socket => {
  let currentRoom = null;
  let playerId = null;

  socket.on("message", raw => {
    try {
      const msg = JSON.parse(raw.toString());

      if (msg.type === "CREATE_ROOM") {
        playerId = String(msg.playerId);
        const player = {
          id: playerId,
          name: msg.name || "بازیکن",
          connected: true,
          ready: false,
          socket
        };
        currentRoom = createRoom(player);
        socket.send(JSON.stringify({
          type:"ROOM_CREATED",
          room: publicState(currentRoom)
        }));
        return;
      }

      if (msg.type === "JOIN_ROOM") {
        playerId = String(msg.playerId);
        const room = rooms.get(String(msg.code).toUpperCase());
        if (!room) throw new Error("اتاق پیدا نشد");

        const player = {
          id: playerId,
          name: msg.name || "بازیکن",
          connected: true,
          ready: false,
          socket
        };
        joinRoom(room, player);
        currentRoom = room;
        broadcast(room, {type:"ROOM_STATE", room:publicState(room)});
        return;
      }

      if (!currentRoom || !playerId) {
        throw new Error("ابتدا وارد اتاق شوید");
      }

      if (msg.type === "READY") {
        const p = findPlayer(currentRoom, playerId);
        p.ready = Boolean(msg.value);
        broadcast(currentRoom, {type:"ROOM_STATE", room:publicState(currentRoom)});
        return;
      }

      if (msg.type === "PING") {
        socket.send(JSON.stringify({type:"PONG", at:Date.now()}));
        return;
      }

      // حرکت‌های بازی در مرحله بعد به موتور v18 متصل می‌شوند.
      if (msg.type === "PLAY_CARD") {
        broadcast(currentRoom, {
          type:"MOVE_RECEIVED",
          playerId,
          card: msg.card || null
        });
        return;
      }

      sendError(socket, "پیام ناشناخته");
    } catch (err) {
      sendError(socket, err.message || "خطای سرور");
    }
  });

  socket.on("close", () => {
    if (!currentRoom || !playerId) return;
    const p = findPlayer(currentRoom, playerId);
    if (p) {
      p.connected = false;
      p.socket = null;
      broadcast(currentRoom, {type:"ROOM_STATE", room:publicState(currentRoom)});
    }
  });
});

httpServer.listen(PORT, () => {
  console.log(`Hokm Online v20 realtime server listening on ${PORT}`);
});
