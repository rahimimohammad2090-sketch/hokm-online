// Hokm Online v23
// اتصال کامل UI به موتور بازی با حفظ محرمانگی دست هر بازیکن

const http = require("http");
const WebSocket = require("ws");
const {newGame, deal, play} = require("./v21_game_engine");

const PORT = process.env.PORT || 3000;
const rooms = new Map();

function roomCode() {
  let c;
  do c = Math.random().toString(36).slice(2,8).toUpperCase();
  while (rooms.has(c));
  return c;
}

function broadcast(room, message) {
  const data = JSON.stringify(message);
  room.players.forEach(p => {
    if (p.socket && p.socket.readyState === WebSocket.OPEN) p.socket.send(data);
  });
}

function sendPrivate(player, message) {
  if (player.socket && player.socket.readyState === WebSocket.OPEN)
    player.socket.send(JSON.stringify(message));
}

function publicState(room) {
  const g = room.game;
  return {
    code: room.code,
    status: room.status,
    players: room.players.map(p => ({
      id:p.id, name:p.name, connected:p.connected, ready:p.ready
    })),
    game: g ? {
      phase:g.phase,
      turn:g.turn,
      round:g.round,
      trump:g.trump,
      roundWins:g.roundWins,
      trick:g.trick
    } : null
  };
}

function sendAllStates(room) {
  room.players.forEach((p, index) => {
    sendPrivate(p, {
      type:"GAME_STATE",
      room:publicState(room),
      playerIndex:index,
      hand: room.game ? room.game.hands[index] : []
    });
  });
}

function startGame(room) {
  room.game = deal(newGame());
  room.status = "PLAYING";
  sendAllStates(room);
}

const httpServer = http.createServer((req,res) => {
  if (req.url === "/health") {
    res.writeHead(200, {"Content-Type":"application/json"});
    res.end(JSON.stringify({ok:true,version:"23v"}));
    return;
  }
  res.writeHead(404);
  res.end();
});

const wss = new WebSocket.Server({server:httpServer});

wss.on("connection", socket => {
  let room = null;
  let playerId = null;

  socket.on("message", raw => {
    try {
      const m = JSON.parse(raw.toString());

      if (m.type === "CREATE_ROOM") {
        playerId = String(m.playerId);
        room = {
          code:roomCode(),
          status:"WAITING",
          players:[{
            id:playerId,name:m.name||"بازیکن",
            connected:true,ready:false,socket
          }],
          game:null
        };
        rooms.set(room.code, room);
        socket.send(JSON.stringify({type:"ROOM_CREATED",room:publicState(room)}));
        return;
      }

      if (m.type === "JOIN_ROOM") {
        const target = rooms.get(String(m.code).toUpperCase());
        if (!target) throw new Error("ROOM_NOT_FOUND");
        if (target.status !== "WAITING") throw new Error("GAME_ALREADY_STARTED");
        if (target.players.length >= 4) throw new Error("ROOM_FULL");

        playerId = String(m.playerId);
        if (target.players.some(p=>p.id===playerId))
          throw new Error("PLAYER_ALREADY_IN_ROOM");

        room = target;
        room.players.push({
          id:playerId,name:m.name||"بازیکن",
          connected:true,ready:false,socket
        });
        broadcast(room,{type:"ROOM_STATE",room:publicState(room)});
        return;
      }

      if (!room) throw new Error("NOT_IN_ROOM");
      const me = room.players.find(p=>p.id===playerId);
      if (!me) throw new Error("PLAYER_NOT_FOUND");

      if (m.type === "READY") {
        if (room.status !== "WAITING") throw new Error("GAME_ALREADY_STARTED");
        me.ready = Boolean(m.value);

        if (room.players.length === 4 && room.players.every(p=>p.ready)) {
          startGame(room);
          broadcast(room,{type:"GAME_STARTED",room:publicState(room)});
          sendAllStates(room);
        } else {
          broadcast(room,{type:"ROOM_STATE",room:publicState(room)});
        }
        return;
      }

      if (m.type === "SET_TRUMP") {
        if (!room.game) throw new Error("GAME_NOT_STARTED");
        if (room.game.trump) throw new Error("TRUMP_ALREADY_SET");
        const playerIndex = room.players.findIndex(p=>p.id===playerId);
        if (playerIndex !== 0) throw new Error("NOT_HAKEM");
        if (!["♠","♥","♦","♣"].includes(m.trump)) throw new Error("INVALID_TRUMP");

        room.game.trump = m.trump;
        sendAllStates(room);
        return;
      }

      if (m.type === "PLAY_CARD") {
        if (!room.game || room.status !== "PLAYING")
          throw new Error("GAME_NOT_PLAYING");

        const playerIndex = room.players.findIndex(p=>p.id===playerId);
        const result = play(room.game, playerIndex, m.card);

        // فقط وضعیت عمومی + دست خصوصی هر بازیکن ارسال می‌شود.
        sendAllStates(room);

        broadcast(room,{
          type:"TRICK_UPDATE",
          playerId,
          card:m.card,
          result
        });

        if (result.gameFinished) {
          room.status = "FINISHED";
          broadcast(room,{type:"GAME_FINISHED",room:publicState(room)});
        }
        return;
      }

      if (m.type === "PING") {
        socket.send(JSON.stringify({type:"PONG",at:Date.now()}));
        return;
      }

      throw new Error("UNKNOWN_MESSAGE");
    } catch (e) {
      socket.send(JSON.stringify({type:"ERROR",message:e.message || "SERVER_ERROR"}));
    }
  });

  socket.on("close", () => {
    if (!room || !playerId) return;
    const p = room.players.find(x=>x.id===playerId);
    if (p) {
      p.connected = false;
      p.socket = null;
      broadcast(room,{type:"ROOM_STATE",room:publicState(room)});
    }
  });
});

httpServer.listen(PORT,()=>console.log("Hokm Online v23 server:",PORT));
