class ProductionAuditLog {
  constructor({ maxEntries = 20000 } = {}) { this.maxEntries=maxEntries; this.entries=[]; }
  record({ userId=null, actionId=null, type=null, status, error=null, ts=Date.now(), latencyMs=null }) {
    const e={id:`${ts}-${this.entries.length}`,userId,actionId,type,status,error,latencyMs,ts};
    this.entries.push(e); if(this.entries.length>this.maxEntries)this.entries.shift(); return {...e};
  }
  list(){return this.entries.map(e=>({...e}));}
  counts(){return this.entries.reduce((a,e)=>{a[e.status]=(a[e.status]||0)+1;return a;},{});}
}
module.exports={ProductionAuditLog};
