-- v28 Matchmaking persistence
CREATE TABLE IF NOT EXISTS matchmaking_tickets (
  ticket_id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mode VARCHAR(20) NOT NULL DEFAULT 'classic',
  rating INTEGER NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'queued',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  matched_at TIMESTAMPTZ,
  room_code VARCHAR(6)
);
CREATE INDEX IF NOT EXISTS idx_mm_queue
ON matchmaking_tickets(status, mode, rating, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_mm_active_user
ON matchmaking_tickets(user_id) WHERE status='queued';
