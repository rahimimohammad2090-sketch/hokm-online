Hokm Online v33 — Production Stability
Idempotency + Rate Limit + Sequence Guard
v32 Recovery/Snapshot/Timeout/Reconnect retained.
