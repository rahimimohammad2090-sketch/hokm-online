// Hokm Online v24
// WebSocket + احراز هویت
const http = require("http");
const WebSocket = require("ws");
const {
  createUser, authenticate
} = require("./v24_auth_store");
const {
  createSession, getSession
} = require("./v24_session");
const {newGame, deal, play} = require("./v21_game_engine");

const PORT = process.env.PORT || 3000;
const rooms = new Map();

function code() {
  let c;
  do c = Math.random().toString(36).slice(2,8).toUpperCase();
  while (rooms.has(c));
  return c;
}

function send(socket, type, payload={}) {
  if (socket.readyState === WebSocket.OPEN)
    socket.send(JSON.stringify({type, ...payload}));
}

function broadcast(room, type, payload={}) {
  room.players.forEach(p => send(p.socket, type, payload));
}

function publicState(room) {
  const g = room.game;
  return {
    code: room.code,
    status: room.status,
    players: room.players.map(p => ({
      id:p.id, name:p.name, connected:p.connected, ready:p.ready
    })),
    game:g ? {
      phase:g.phase, turn:g.turn, round:g.round,
      trump:g.trump, roundWins:g.roundWins, trick:g.trick
    } : null
  };
}

function sendStates(room) {
  room.players.forEach((p,i) => send(p.socket, "GAME_STATE", {
    room:publicState(room),
    playerIndex:i,
    hand:room.game ? room.game.hands[i] : []
  }));
}

function startGame(room) {
  room.game = deal(newGame());
  room.status = "PLAYING";
  sendStates(room);
}

const server = http.createServer((req,res) => {
  res.setHeader("Content-Type","application/json; charset=utf-8");
  if (req.url === "/health") {
    return res.end(JSON.stringify({ok:true,version:"24v"}));
  }
  res.statusCode = 404;
  res.end(JSON.stringify({error:"NOT_FOUND"}));
});

const wss = new WebSocket.Server({server});

wss.on("connection", socket => {
  let user = null;
  let room = null;

  socket.on("message", raw => {
    try {
      const m = JSON.parse(raw.toString());

      if (m.type === "REGISTER") {
        const profile = createUser(m.username, m.password, m.displayName);
        const token = createSession(profile);
        return send(socket, "AUTH_OK", {token, user:profile});
      }

      if (m.type === "LOGIN") {
        const profile = authenticate(m.username, m.password);
        const token = createSession(profile);
        return send(socket, "AUTH_OK", {token, user:profile});
      }

      if (m.type === "AUTH") {
        user = getSession(m.token);
        if (!user) throw new Error("INVALID_SESSION");
        return send(socket, "AUTHENTICATED", {user});
      }

      if (m.type === "PING") return send(socket,"PONG",{at:Date.now()});

      if (!user) throw new Error("AUTH_REQUIRED");

      if (m.type === "CREATE_ROOM") {
        room = {
          code:code(), status:"WAITING",
          players:[{
            id:user.id, name:user.displayName,
            connected:true, ready:false, socket
          }],
          game:null
        };
        rooms.set(room.code, room);
        return send(socket,"ROOM_CREATED",{room:publicState(room)});
      }

      if (m.type === "JOIN_ROOM") {
        const target = rooms.get(String(m.code).toUpperCase());
        if (!target) throw new Error("ROOM_NOT_FOUND");
        if (target.status !== "WAITING") throw new Error("GAME_ALREADY_STARTED");
        if (target.players.length >= 4) throw new Error("ROOM_FULL");
        if (target.players.some(p=>p.id===user.id))
          throw new Error("PLAYER_ALREADY_IN_ROOM");

        room = target;
        room.players.push({
          id:user.id, name:user.displayName,
          connected:true, ready:false, socket
        });
        return broadcast(room,"ROOM_STATE",{room:publicState(room)});
      }

      if (!room) throw new Error("NOT_IN_ROOM");
      const me = room.players.find(p=>p.id===user.id);
      if (!me) throw new Error("PLAYER_NOT_FOUND");

      if (m.type === "READY") {
        if (room.status !== "WAITING") throw new Error("GAME_ALREADY_STARTED");
        me.ready = Boolean(m.value);
        if (room.players.length === 4 && room.players.every(p=>p.ready)) {
          startGame(room);
          broadcast(room,"GAME_STARTED",{room:publicState(room)});
          sendStates(room);
        } else {
          broadcast(room,"ROOM_STATE",{room:publicState(room)});
        }
        return;
      }

      if (m.type === "SET_TRUMP") {
        if (!room.game) throw new Error("GAME_NOT_STARTED");
        const idx = room.players.findIndex(p=>p.id===user.id);
        if (idx !== 0) throw new Error("NOT_HAKEM");
        if (room.game.trump) throw new Error("TRUMP_ALREADY_SET");
        if (!["♠","♥","♦","♣"].includes(m.trump)) throw new Error("INVALID_TRUMP");
        room.game.trump = m.trump;
        return sendStates(room);
      }

      if (m.type === "PLAY_CARD") {
        if (!room.game || room.status !== "PLAYING")
          throw new Error("GAME_NOT_PLAYING");
        const idx = room.players.findIndex(p=>p.id===user.id);
        const result = play(room.game, idx, m.card);
        sendStates(room);
        broadcast(room,"TRICK_UPDATE",{playerId:user.id,card:m.card,result});
        if (result.gameFinished) {
          room.status = "FINISHED";
          broadcast(room,"GAME_FINISHED",{room:publicState(room)});
        }
        return;
      }

      throw new Error("UNKNOWN_MESSAGE");
    } catch (e) {
      send(socket,"ERROR",{message:e.message || "SERVER_ERROR"});
    }
  });

  socket.on("close", () => {
    if (!room || !user) return;
    const p = room.players.find(x=>x.id===user.id);
    if (p) {
      p.connected = false;
      p.socket = null;
      broadcast(room,"ROOM_STATE",{room:publicState(room)});
    }
  });
});

server.listen(PORT,()=>console.log("Hokm Online v24 auth server:",PORT));
