-- Hokm Online v27
-- Profile, XP, levels, rating and match history

ALTER TABLE player_stats
  ADD COLUMN IF NOT EXISTS xp BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS level INTEGER NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS rating INTEGER NOT NULL DEFAULT 1000,
  ADD COLUMN IF NOT EXISTS streak INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS best_streak INTEGER NOT NULL DEFAULT 0;

ALTER TABLE game_history
  ADD COLUMN IF NOT EXISTS mode VARCHAR(20) NOT NULL DEFAULT 'classic';

CREATE TABLE IF NOT EXISTS player_achievements (
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  achievement_code VARCHAR(50) NOT NULL,
  unlocked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY(user_id, achievement_code)
);

CREATE INDEX IF NOT EXISTS idx_player_stats_rating
ON player_stats(rating DESC);

CREATE INDEX IF NOT EXISTS idx_player_stats_xp
ON player_stats(xp DESC);
