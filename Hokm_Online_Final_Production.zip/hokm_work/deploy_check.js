const assert=require('assert');
const {productionConfig}=require('./v37_config');
const {validateTlsConfig}=require('./tls_policy');
const {loadSecret}=require('./secret_provider');
const fs=require('fs'),os=require('os'),path=require('path');
(()=>{
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'hokm-')); const cert=path.join(d,'cert.pem'),key=path.join(d,'key.pem'),secret=path.join(d,'secret');
 fs.writeFileSync(cert,'CERT');fs.writeFileSync(key,'KEY');fs.writeFileSync(secret,'x'.repeat(48));
 const env={NODE_ENV:'production',AUTH_SECRET:'x'.repeat(48),TLS_ENABLED:'true',TLS_CERT_FILE:cert,TLS_KEY_FILE:key,PERSISTENCE_DRIVER:'postgres',REDIS_ENABLED:'true'};
 assert.equal(productionConfig(env).persistenceDriver,'postgres'); assert.equal(validateTlsConfig(env).ok,true);
 assert.equal(loadSecret({env:{AUTH_SECRET_FILE:secret}}).length,48);
 assert.equal(validateTlsConfig({...env,TLS_KEY_FILE:'/missing'}).error,'TLS_KEY_FILE_UNREADABLE');
 console.log('deployment config + secret + TLS tests: PASS');
})()
