// v28 client flow
function findMatch(ws, mode="classic") {
  ws.send(JSON.stringify({type:"FIND_MATCH",mode}));
}
function cancelMatch(ws) {
  ws.send(JSON.stringify({type:"CANCEL_MATCH"}));
}
function queueStatus(ws) {
  ws.send(JSON.stringify({type:"QUEUE_STATUS"}));
}
// Server events:
// QUEUED -> waiting
// QUEUE_STATUS -> current ticket
// MATCH_FOUND -> connect/open the assigned match room
// MATCH_CANCELLED -> return to lobby
