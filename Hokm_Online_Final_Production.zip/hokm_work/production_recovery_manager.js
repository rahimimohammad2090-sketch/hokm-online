// Durable recovery manager: snapshots are checkpoints, so only events after
// the snapshot sequence are replayed. Supports both sync and async stores.
class RecoveryManager {
  constructor(store) {
    if (!store || typeof store.loadSnapshot !== 'function' || typeof store.readEvents !== 'function') {
      throw new Error('RECOVERY_STORE_INVALID');
    }
    this.store = store;
  }

  async record(id, event) {
    return this.store.append(id, event);
  }

  async checkpoint(id, state, seq = null) {
    const snapshot = { state, seq };
    return this.store.saveSnapshot(id, snapshot);
  }

  async recover(id, applyEvent, initialState = {}) {
    if (typeof applyEvent !== 'function') throw new Error('RECOVERY_APPLY_HANDLER_MISSING');
    const raw = await this.store.loadSnapshot(id);
    const hasCheckpointEnvelope = raw && Object.prototype.hasOwnProperty.call(raw, 'state');
    const state = structuredClone(hasCheckpointEnvelope ? raw.state : (raw || initialState));
    const checkpointSeq = hasCheckpointEnvelope && Number.isInteger(raw.seq) ? raw.seq : 0;
    const events = await this.store.readEvents(id);
    for (const event of events) {
      if (Number.isInteger(event.seq) && event.seq <= checkpointSeq) continue;
      await applyEvent(state, event);
    }
    return { state, checkpointSeq, replayedEvents: events.filter(e => !Number.isInteger(e.seq) || e.seq > checkpointSeq).length };
  }
}
module.exports = { RecoveryManager };
