class MemoryPersistence{
constructor(){this.events=new Map();this.snapshots=new Map()}
append(id,event){if(!this.events.has(id))this.events.set(id,[]);const a=this.events.get(id);if(a.some(e=>e.seq===event.seq))return a.find(e=>e.seq===event.seq);a.push({...event});a.sort((x,y)=>x.seq-y.seq);return event}
readEvents(id){return [...(this.events.get(id)||[])]}
saveSnapshot(id,state){this.snapshots.set(id,JSON.parse(JSON.stringify(state)))}
loadSnapshot(id){const s=this.snapshots.get(id);return s?JSON.parse(JSON.stringify(s)):null}}
class RedisPersistence{
constructor(redis){this.redis=redis}
async append(id,event){await this.redis.rPush(`hokm:${id}:events`,JSON.stringify(event));return event}
async readEvents(id){return (await this.redis.lRange(`hokm:${id}:events`,0,-1)).map(JSON.parse)}
async saveSnapshot(id,state){await this.redis.set(`hokm:${id}:snapshot`,JSON.stringify(state))}
async loadSnapshot(id){const x=await this.redis.get(`hokm:${id}:snapshot`);return x?JSON.parse(x):null}}
class PostgresPersistence{
constructor(pool){this.pool=pool}
async append(id,event){await this.pool.query(`INSERT INTO hokm_events(match_id,seq,type,payload,ts) VALUES($1,$2,$3,$4,$5) ON CONFLICT(match_id,seq) DO NOTHING`,[id,event.seq,event.type,event.payload||{},event.ts||Date.now()]);return event}
async readEvents(id){return (await this.pool.query(`SELECT seq,type,payload,ts FROM hokm_events WHERE match_id=$1 ORDER BY seq`,[id])).rows}
async saveSnapshot(id,state){await this.pool.query(`INSERT INTO hokm_snapshots(match_id,state,ts) VALUES($1,$2,$3) ON CONFLICT(match_id) DO UPDATE SET state=EXCLUDED.state,ts=EXCLUDED.ts`,[id,state,Date.now()])}
async loadSnapshot(id){return (await this.pool.query(`SELECT state FROM hokm_snapshots WHERE match_id=$1`,[id])).rows[0]?.state||null}}
module.exports={MemoryPersistence,RedisPersistence,PostgresPersistence};
