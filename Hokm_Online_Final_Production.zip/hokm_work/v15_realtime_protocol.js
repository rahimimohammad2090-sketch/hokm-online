// قرارداد پیام‌های آنلاین v15
// مناسب برای WebSocket / Socket.IO یا هر سرور realtime

const EVENTS = {
  CREATE_ROOM: "room:create",
  JOIN_ROOM: "room:join",
  LEAVE_ROOM: "room:leave",
  READY: "room:ready",
  START: "room:start",
  STATE: "game:state",
  PLAY_CARD: "game:playCard",
  RESULT: "game:result",
  ERROR: "game:error"
};

function packet(event, payload = {}) {
  return {
    event,
    timestamp: Date.now(),
    payload
  };
}

module.exports = {EVENTS, packet};
