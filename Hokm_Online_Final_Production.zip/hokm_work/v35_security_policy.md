# v35 Security Policy
Secrets from environment/secret manager. TLS in production. Authenticate and authorize before game execution. Players control only their own seats. Validate actionId/sequence. Use secure cookies/CSRF protection for browser sessions. Keep audit logs and rate limiting.
