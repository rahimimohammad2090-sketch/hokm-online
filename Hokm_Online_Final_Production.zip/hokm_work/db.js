// Hokm Online v25 - PostgreSQL repository
// npm install pg

const { Pool } = require("pg");
const crypto = require("crypto");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30000
});

async function createUser(user) {
  const id = user.id || crypto.randomUUID();
  const q = `
    INSERT INTO users(id, username, display_name, password_hash, password_salt)
    VALUES($1,$2,$3,$4,$5)
    RETURNING id, username, display_name, created_at`;
  const r = await pool.query(q, [
    id, user.username, user.displayName,
    user.passwordHash, user.salt
  ]);
  await pool.query(
    `INSERT INTO player_stats(user_id) VALUES($1) ON CONFLICT DO NOTHING`,
    [id]
  );
  return r.rows[0];
}

async function findUser(username) {
  const r = await pool.query(
    `SELECT id, username, display_name, password_hash, password_salt
     FROM users WHERE username=$1`,
    [username]
  );
  return r.rows[0] || null;
}

async function recordGame(game) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(
      `INSERT INTO game_history
       (id, room_code, started_at, finished_at, winner_team, result_json)
       VALUES($1,$2,$3,$4,$5,$6)`,
      [game.id, game.roomCode, game.startedAt, game.finishedAt,
       game.winnerTeam, JSON.stringify(game.result || {})]
    );

    for (const p of game.players) {
      await client.query(
        `INSERT INTO game_players(game_id,user_id,team,seat,score,won)
         VALUES($1,$2,$3,$4,$5,$6)`,
        [game.id,p.userId,p.team,p.seat,p.score,Boolean(p.won)]
      );

      await client.query(
        `UPDATE player_stats
         SET games_played=games_played+1,
             games_won=games_won+$2,
             total_score=total_score+$3,
             updated_at=NOW()
         WHERE user_id=$1`,
        [p.userId, p.won ? 1 : 0, p.score || 0]
      );
    }
    await client.query("COMMIT");
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}

async function getStats(userId) {
  const r = await pool.query(
    `SELECT games_played, games_won, total_score
     FROM player_stats WHERE user_id=$1`,
    [userId]
  );
  return r.rows[0] || {games_played:0,games_won:0,total_score:0};
}

module.exports = {pool, createUser, findUser, recordGame, getStats};
